<?php
	class_exists('XenForo_Application', false) || die('Invalid');

	$__extraData['title'] = 'XenForo';

	echo $message;
?>